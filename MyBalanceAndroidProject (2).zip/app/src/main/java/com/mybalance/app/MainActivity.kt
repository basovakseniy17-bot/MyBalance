package com.mybalance.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { MaterialTheme { BalanceApp() } }
 }
}

data class Meal(val title:String,val main:String,val alt:String)
val meals = listOf(
 Meal("Завтрак","Овсянка 50 г + йогурт 150 г + ягоды + 2 яйца","Омлет из 2 яиц + хлеб 40 г + овощи + фрукт"),
 Meal("Обед","Курица/индейка 130 г + гречка 150 г + овощи","Рыба 150 г + картофель 150–200 г + салат"),
 Meal("Перекус","Творог 150 г + яблоко","Йогурт 150–200 г + банан + 10–15 г орехов"),
 Meal("Ужин","Рыба 150 г + картофель/рис + овощи","Курица 130 г + гречка 150 г + овощи")
)
val exercises = listOf(
 "Разминка — 8–10 мин: ходьба на месте, суставная разминка",
 "Приседания с резинкой — 3×12",
 "Ягодичный мост с резинкой — 3×15",
 "Тяга резинки к корпусу — 3×12",
 "Разведение резинки — 3×12",
 "Выпады — 3×10 на каждую ногу",
 "Планка — 3×30–45 сек",
 "Dead bug — 3×10 на сторону",
 "Заминка — 5–8 мин"
)

@Composable fun BalanceApp() {
 var tab by remember { mutableIntStateOf(0) }
 var water by remember { mutableIntStateOf(0) }
 var workoutDone by remember { mutableStateOf(false) }
 var meal by remember { mutableStateOf(meals[0]) }
 Scaffold(bottomBar={
  NavigationBar {
   listOf("Сегодня","Питание","Тренировка","Прогресс").forEachIndexed { i,s ->
    NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(
      when(i){0->Icons.Default.Home;1->Icons.Default.Restaurant;2->Icons.Default.FitnessCenter;else->Icons.Default.Insights},"")},label={Text(s)})
   }
  }
 }) { p -> Box(Modifier.padding(p)) {
  when(tab){
   0 -> Home(water,{water=(water+1).coerceAtMost(6)},workoutDone)
   1 -> Food(meal){ meal=it }
   2 -> Workout(workoutDone){ workoutDone=true }
   else -> Progress(water,workoutDone)
  }
 }}
}

@Composable fun Home(water:Int,addWater:()->Unit,done:Boolean){
 LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  item { Text("Мой баланс 🌿",style=MaterialTheme.typography.headlineMedium); Text("168 см · 56 кг · 23 года") }
  item { Card { Column(Modifier.padding(16.dp)) {
   Text("Сегодня",style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(10.dp))
   Text("💧 Вода: $water / 6 стаканов"); LinearProgressIndicator({water/6f},Modifier.fillMaxWidth())
   Button(onClick=addWater,Modifier.padding(top=10.dp)){Text("+ Стакан воды")}
  }}}
  item { Card { Column(Modifier.padding(16.dp)) {
   Text("Цель",style=MaterialTheme.typography.titleLarge)
   Text("Подтянутое тело без экстремальной сушки.")
   Text("Белок: ориентир 90–110 г/день · вода по жажде · 3 силовые тренировки/нед.")
  }}}
  item { Text(if(done) "✓ Тренировка сегодня выполнена" else "Сегодня: тренировка по плану — 60 минут") }
 }
}

@Composable fun Food(selected:Meal,onSelect:(Meal)->Unit){
 LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item { Text("Питание",style=MaterialTheme.typography.headlineMedium); Text("Регулярное питание и достаточный белок важнее жёсткой сушки.") }
  items(meals){ m -> Card { Column(Modifier.padding(16.dp)){
   Text(m.title,style=MaterialTheme.typography.titleMedium); Text(m.main); Text("🔄 Замена: ${m.alt}")
   OutlinedButton(onClick={onSelect(m)},Modifier.padding(top=8.dp)){Text(if(selected==m)"Выбрано" else "Выбрать")}
  }}}
 }
}

@Composable fun Workout(done:Boolean,finish:()->Unit){
 LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item { Text("Полное тело · 60 минут",style=MaterialTheme.typography.headlineMedium); Text("Дом + резинки · 3 раза в неделю") }
  items(exercises){ Text("• $it",Modifier.padding(vertical=5.dp)) }
  item { Button(onClick=finish,enabled=!done,Modifier.fillMaxWidth()){Text(if(done)"✓ Выполнено" else "Завершить тренировку")} }
 }
}

@Composable fun Progress(water:Int,done:Boolean){
 LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  item { Text("Прогресс",style=MaterialTheme.typography.headlineMedium) }
  item { Card { Column(Modifier.padding(16.dp)){
   Text("Сегодня"); Text("Вода: $water/6"); Text("Тренировка: ${if(done)"выполнена ✓" else "ещё нет"}")
  }}}
  item { Text("💡 Не оценивай результат только по весу: фото, замеры, сила и самочувствие тоже важны.") }
 }
}